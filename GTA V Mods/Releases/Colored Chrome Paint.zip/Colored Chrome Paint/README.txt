----GTA V Colored Chrome Paint v1.1----
Written by camismacho

PLEASE BACK UP YOUR FILES BEFORE INSTALLING THIS!!!
PLEASE READ ALL INSTRUCTIONS FOR MOD COMPATIBILITY!!!

Thank you for downloading my Colored Chrome Paint mod!

This mod will replace the last 13 matte paints in LS Customs with new chrome colors.

New in v1.1: Chrome Gold

The colors are as follows:
--Chrome--	--Matte Replaced--
Gold		Midnight Blue
White 	 	Midnight Purple
Black 	 	Schafter Purple
Electric Blue 	Red
Mint Green  	Dark Red
Lime Green  	Orange
Yellow  	Yellow
Golden Shower	Lime Green
Orange 		Green
Red  		Forest Green
Pony Pink  	Foliage Green
Hot Pink  	Olive Drab
Purple  	Dark Earth
Blacklight  	Desert Tan

The next version of this mod will replace "Worn" colors instead so you can keep your mattes, but will need to be accessed via trainer.

*Warning!*
If you're already using a mod that replaces the "carcols.ymt" (police light mods, graphics mods, etc.) 
This mod will overwrite that file and you will lose those settings!
Please check your mods before installation!

***INSTALLATION***
 
Copy carcols.ymt using OpenIV to:
	mods\update\update.rpf\x64\data

Enjoy your Colored Chrome Paint!







