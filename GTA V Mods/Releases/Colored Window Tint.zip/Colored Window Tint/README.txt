----GTA V Colored Window Tint----
Written by camismacho

PLEASE BACK UP YOUR FILES BEFORE INSTALLING THIS!!!
PLEASE READ ALL INSTRUCTIONS FOR MOD COMPATIBILITY!!!

Thank you for downloading my Colored Window Tint mod!

I have included 3 colors with the initial release of this mod; Red, Green, and Blue

This mod will replace your 3 tint options in LS Customs with new colors.

Each color has 3 different shades, just like the normal black tint in game; Light, Dark, and Limo

You can choose a single color, or choose the "Multicolor" file to have all 3 in game at once.
	(You can only have one shade of the "Multicolor" at a time. I'm working on a way to add more tint options in LS Customs.)

*Warning!*
If you're already using a mod that replaces the "carcols.ymt" (police light mods, graphics mods, etc.) 
This mod will overwrite that file and you will lose those settings!
Please check your mods before installation!

***INSTALLATION***
 
1: Navigate to the "Colors" folder

2: Choose your color and click on its folder

3: Copy carcols.ymt using OpenIV to:
	mods\update\update.rpf\x64\data

Enjoy your Colored Tint!

If someone knows how to add an extra tint option in LS Customs, feel free to contact me.








