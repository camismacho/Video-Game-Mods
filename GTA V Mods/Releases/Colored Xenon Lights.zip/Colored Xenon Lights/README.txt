----GTA V Colored Xenon Lights----
Written by camismacho

PLEASE BACK UP YOUR FILES BEFORE INSTALLING THIS!!!
PLEASE READ ALL INSTRUCTIONS FOR MOD COMPATIBILITY!!!

Thank you for downloading my Colored Xenon Lights mod!

This mod will replace the Xenon Lights customization with new colors!

This mod was created using Natural Vision Remastered and VisualV.
Your colors may vary slightly depending on your graphics mods.

The colors are as follows:
--Temperature Kelvin--	--Color--
3000K			JDM Yellow
4300K 	 		Daylight White
6000K 	 		Cool White
8000K	 		Ice Blue
10000K  		Blue
12000K  		Purple
15000K  		Pink
Green			Green
Orange 			Orange
Red  			Red


*Warning!*
If you're already using a mod that replaces the "carcols.ymt" (police light mods, graphics mods, etc.) 
This mod will overwrite that file and you will lose those settings!
Please check your mods before installation!

***INSTALLATION***

1: Choose your preferred color and open its folder.
 
2: Copy carcols.ymt using OpenIV to:
	mods\update\update.rpf\x64\data

Enjoy your Colored Xenon Lights!







